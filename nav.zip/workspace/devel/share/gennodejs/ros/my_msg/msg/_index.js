
"use strict";

let new_my_msg = require('./new_my_msg.js');

module.exports = {
  new_my_msg: new_my_msg,
};
