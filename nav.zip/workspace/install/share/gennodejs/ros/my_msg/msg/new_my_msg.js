// Auto-generated. Do not edit!

// (in-package my_msg.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class new_my_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ftext = null;
      this.fnum = null;
      this.stext = null;
      this.snum = null;
    }
    else {
      if (initObj.hasOwnProperty('ftext')) {
        this.ftext = initObj.ftext
      }
      else {
        this.ftext = '';
      }
      if (initObj.hasOwnProperty('fnum')) {
        this.fnum = initObj.fnum
      }
      else {
        this.fnum = 0;
      }
      if (initObj.hasOwnProperty('stext')) {
        this.stext = initObj.stext
      }
      else {
        this.stext = '';
      }
      if (initObj.hasOwnProperty('snum')) {
        this.snum = initObj.snum
      }
      else {
        this.snum = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type new_my_msg
    // Serialize message field [ftext]
    bufferOffset = _serializer.string(obj.ftext, buffer, bufferOffset);
    // Serialize message field [fnum]
    bufferOffset = _serializer.int32(obj.fnum, buffer, bufferOffset);
    // Serialize message field [stext]
    bufferOffset = _serializer.string(obj.stext, buffer, bufferOffset);
    // Serialize message field [snum]
    bufferOffset = _serializer.int32(obj.snum, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type new_my_msg
    let len;
    let data = new new_my_msg(null);
    // Deserialize message field [ftext]
    data.ftext = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [fnum]
    data.fnum = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [stext]
    data.stext = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [snum]
    data.snum = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.ftext.length;
    length += object.stext.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'my_msg/new_my_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9b5345d078510c5c4199590b356b3ad2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string ftext
    int32 fnum
    string stext
    int32 snum
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new new_my_msg(null);
    if (msg.ftext !== undefined) {
      resolved.ftext = msg.ftext;
    }
    else {
      resolved.ftext = ''
    }

    if (msg.fnum !== undefined) {
      resolved.fnum = msg.fnum;
    }
    else {
      resolved.fnum = 0
    }

    if (msg.stext !== undefined) {
      resolved.stext = msg.stext;
    }
    else {
      resolved.stext = ''
    }

    if (msg.snum !== undefined) {
      resolved.snum = msg.snum;
    }
    else {
      resolved.snum = 0
    }

    return resolved;
    }
};

module.exports = new_my_msg;
