// Auto-generated. Do not edit!

// (in-package my_service.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class addintsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.fint = null;
      this.sint = null;
    }
    else {
      if (initObj.hasOwnProperty('fint')) {
        this.fint = initObj.fint
      }
      else {
        this.fint = 0;
      }
      if (initObj.hasOwnProperty('sint')) {
        this.sint = initObj.sint
      }
      else {
        this.sint = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type addintsRequest
    // Serialize message field [fint]
    bufferOffset = _serializer.int32(obj.fint, buffer, bufferOffset);
    // Serialize message field [sint]
    bufferOffset = _serializer.int32(obj.sint, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type addintsRequest
    let len;
    let data = new addintsRequest(null);
    // Deserialize message field [fint]
    data.fint = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [sint]
    data.sint = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'my_service/addintsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '83b51d88852db78abaec64852d974b9c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 fint
    int32 sint
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new addintsRequest(null);
    if (msg.fint !== undefined) {
      resolved.fint = msg.fint;
    }
    else {
      resolved.fint = 0
    }

    if (msg.sint !== undefined) {
      resolved.sint = msg.sint;
    }
    else {
      resolved.sint = 0
    }

    return resolved;
    }
};

class addintsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sum = null;
    }
    else {
      if (initObj.hasOwnProperty('sum')) {
        this.sum = initObj.sum
      }
      else {
        this.sum = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type addintsResponse
    // Serialize message field [sum]
    bufferOffset = _serializer.int32(obj.sum, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type addintsResponse
    let len;
    let data = new addintsResponse(null);
    // Deserialize message field [sum]
    data.sum = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'my_service/addintsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0ba699c25c9418c0366f3595c0c8e8ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 sum
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new addintsResponse(null);
    if (msg.sum !== undefined) {
      resolved.sum = msg.sum;
    }
    else {
      resolved.sum = 0
    }

    return resolved;
    }
};

module.exports = {
  Request: addintsRequest,
  Response: addintsResponse,
  md5sum() { return 'c5750a862d29df6bc891bc05e1b73e2a'; },
  datatype() { return 'my_service/addints'; }
};
