#include "ros/ros.h"
#include "my_msg/new_my_msg.h" //класс публикуемого сообщения
#include <stdlib.h>
#include <stdio.h>
//#include <sstream.h>

my_msg::new_my_msg::_fnum_type minNum = 100;

void reader(const my_msg::new_my_msg & message){//константная ссылка на сообщение из топика


my_msg::new_my_msg::_fnum_type f1num = message.fnum;
my_msg::new_my_msg::_snum_type s1num = message.snum;

ROS_INFO("%s, %d, %s, %d", message.ftext.c_str(), message.fnum, message.stext.c_str(), message.snum);

	if (f1num < minNum) minNum=f1num;
	if (s1num < minNum) minNum=s1num;
	if (f1num == 23) 
		{
		ROS_INFO("%d" , minNum);
		ros::shutdown();
		}
}

int main (int argc, char **argv)
{
	ros::init(argc, argv, "reader");//инициализация основных процессов
	ROS_INFO_STREAM("reader id ready\n");
	ros::NodeHandle n;// объект кот управляет
	ros::Subscriber sub = n.subscribe("Name", 10, reader);
// создание объектра для отправки в типики
//кто управляет. прием(от кого, буфер, функция обраб сообщения)	

	ros::spin();//
	return 0;
}
