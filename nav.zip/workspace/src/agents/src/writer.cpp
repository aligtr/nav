#include "ros/ros.h"
#include "my_msg/new_my_msg.h" //класс публикуемого сообщения
#include <stdlib.h>
#include <stdio.h>
//#include <sstream.h>

//typedef std::pair< std::string, int, std::string, int > TextNum;
struct TextNum    //Создаем структуру!
{                  
    std::string f1text;       //здесь будет храниться имя владельца
     int f1num;        //название города
    std::string s1text;       //здесь будет храниться имя владельца
     int s1num;        //название города
};

int main (int argc, char **argv)
{
	ros::init(argc, argv, "writer");//инициализация основных процессов

	ROS_INFO("Writer is ready:\n");

	ros::NodeHandle n;
	ros::Publisher pub = n.advertise<my_msg::new_my_msg>("Name", 10);

	TextNum messageList[5];	
	messageList[0]={"hello",11,"hello",11};
	messageList[1]={"hello",18,"hello",11};
	messageList[2]={"hello",45,"hello",8};
	messageList[3]={"hello",67,"hello",11};
	messageList[4]={"hello",23,"hello",9};
	sleep(1);
	ros::Rate loop_rate(1);

	for(int i=0; i<5; i++){
		my_msg::new_my_msg message;
		message.ftext = messageList[i].f1text;
		message.fnum = messageList[i].f1num;
		message.stext = messageList[i].s1text;
		message.snum = messageList[i].s1num;
		pub.publish(message);
		ROS_INFO("%s, %d, %s, %d", messageList[i].f1text.c_str(), messageList[i].f1num, messageList[i].s1text.c_str(), messageList[i].s1num);
		ros::spinOnce();
		loop_rate.sleep();
	}
	ROS_INFO_STREAM("publishing is finished\n");
	return 0;
}

