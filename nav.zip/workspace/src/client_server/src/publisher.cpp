#include "ros/ros.h"
#include "my_service/addints.h" //класс публикуемого сообщения
#include <iostream>



int main (int argc, char **argv)
{
	int stop_value;
	ros::init(argc, argv, "add_ints_publisher");//инициализация основных процессов

	ros::NodeHandle n;// объект кот управляет
	ros::ServiceClient client = n.serviceClient<my_service::addints>("add_two_ints");
	my_service::addints srv;
	
	while(ros::ok())
	{
		int a,b;
		std::cout << "inp fint";
		std::cin >> a;
		std::cout << "inp sint";
		std::cin >> b;
		
		srv.request.fint=a;
		srv.request.sint=b;

		if (client.call(srv)) 
		{ 
			ros::param::param<int>("~stop_v", stop_value, 1);
			if (stop_value == srv.response.sum) {std::cout << srv.response.sum*5 << std::endl;}
			else {std::cout << srv.response.sum << std::endl;}
		}
		else 
		{
			std::cout << "fail" << std::endl;
			return 1;
		}
	}
}
