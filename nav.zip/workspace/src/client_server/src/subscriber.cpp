#include "ros/ros.h"
#include "my_service/addints.h" //класс публикуемого сообщения

bool add(my_service::addints::Request &req,
	my_service::addints::Response &res){//константная ссылка на сообщение из топика


res.sum=req.fint+req.sint;

ROS_INFO("%d, %d", req.fint, req.sint);
ROS_INFO("%d", res.sum);
return true;
}

int main (int argc, char **argv)
{
	ros::init(argc, argv, "add_ints_subscriber");//инициализация основных процессов

	ros::NodeHandle n;// объект кот управляет
	ros::ServiceServer service = n.advertiseService("add_two_ints",add);
ROS_INFO("blablabla");

	ros::spin();//
	return 0;
}
