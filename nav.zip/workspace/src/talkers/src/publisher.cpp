#include "ros/ros.h"
#include "geometry_msgs/Twist.h" //класс публикуемого сообщения

int main (int argc, char **argv)
{
	ros::init(argc, argv, "publisher");//инициализация основных процессов
	ros::NodeHandle n;// объект кот управляет
	ros::Publisher pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 1000);
// создание объектра для отправки в типики
//откуда. отправка<тип топика>(имя получателя, буфер)	

	ros::Rate loop_rate(1);// скорость подачи сообщений (1- в сек)
	for (int t=0; t<100; t++){
		geometry_msgs::Twist pos;
		pos.linear.x=1.5;
		pos.angular.z =std::abs(2*sin(0.5*t));
		
		ROS_INFO("move to position:\n"
			"1) pos.lenear: x= %f y= %f z= %f\n"
			"2) pos.angular: x= %f y= %f z= %f\n",
			pos.linear.x, pos.linear.y, pos.linear.z,
			pos.angular.x, pos.angular.y, pos.angular.z);
		pub.publish(pos);
		loop_rate.sleep();
	}
	ros::spinOnce();
	return 0;
}
