# !/bin/bash


catkin_make

source devel/setup.bash
roslaunch client_server roset.launch st:=12
