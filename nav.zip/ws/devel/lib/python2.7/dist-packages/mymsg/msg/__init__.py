from ._newmymsg import *
