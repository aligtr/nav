
"use strict";

let newmymsg = require('./newmymsg.js');

module.exports = {
  newmymsg: newmymsg,
};
