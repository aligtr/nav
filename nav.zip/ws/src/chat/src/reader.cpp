#include "ros/ros.h"
#include "mymsg/newmymsg.h" //класс публикуемого сообщения

int main (int argc, char **argv)
{
	ros::init(argc, argv, "publisher");//инициализация основных процессов
	ros::NodeHandle n;// объект кот управляет
	ros::Publisher pub = n.advertise<mymsg::newmymsg>("mtopic", 1000);
// создание объектра для отправки в типики
//откуда. отправка<тип топика>(имя получателя, буфер)	

	ros::Rate loop_rate(1);// скорость подачи сообщений (1- в сек)
	while(ros::ok){

		//ROS_INFO("move to position:\n");
		mymsg::newmymsg man;
		man.high = 180;
        man.weigh = 80;
        man.name = "pafa";
		pub.publish(man);
		loop_rate.sleep();
	}
	ros::spinOnce();
	return 0;
}