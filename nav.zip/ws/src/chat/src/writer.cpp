#include "ros/ros.h"
#include "mymsg/newmymsg.h" //класс публикуемого сообщения

void prop(const mymsg::newmymsg& new_man)
{
    ROS_INFO("%d,%d, %s", new_man.high, new_man.weigh, new_man.name);
}

int main (int argc, char **argv)
{
	ros::init(argc, argv, "subscriber");//инициализация основных процессов
	ros::NodeHandle n;// объект кот управляет
	ros::Subscriber sub = n.subscribe("mtopic",1000, prop);
	ros::spin();//
	return 0;
}