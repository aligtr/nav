#include "ros/ros.h"
#include "geometry_msgs/Twist.h" //класс публикуемого сообщения

int main (int argc, char **argv)
{
	ros::init(argc, argv, "publisher");//инициализация основных процессов
	ros::NodeHandle n;// объект кот управляет
	ros::Publisher pub = n.advertise<geometry_msgs::Twist>("mtopic", 1000);
// создание объектра для отправки в типики
//откуда. отправка<тип топика>(имя получателя, буфер)	

	ros::Rate loop_rate(1);// скорость подачи сообщений (1- в сек)
	while(ros::ok){

		//ROS_INFO("move to position:\n");
		geometry_msgs::Twist pos;
		pos.linear.x=1.5;
		pos.angular.z =0.5;
		pub.publish(pos);
		loop_rate.sleep();
	}
	ros::spinOnce();
	return 0;
}