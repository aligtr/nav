#include "ros/ros.h"
#include "geometry_msgs/Twist.h" //класс публикуемого сообщения

void reader(const geometry_msgs::Twist& movement)
{
    ROS_INFO("%f, %f", movement.linear.x, movement.angular.z);
}

int main (int argc, char **argv)
{
	ros::init(argc, argv, "subscriber");//инициализация основных процессов
	ros::NodeHandle n;// объект кот управляет
	ros::Subscriber sub = n.subscribe("mtopic",1000, reader);
	ros::spin();//
	return 0;
}